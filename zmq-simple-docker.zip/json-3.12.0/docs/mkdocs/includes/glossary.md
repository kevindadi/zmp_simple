<!-- https://squidfunk.github.io/mkdocs-material/reference/tooltips/#adding-a-glossary -->

*[ADL]: Argument-dependent lookup
*[API]: Application Programming Interfaces
*[ASCII]: American Standard Code for Information Interchange
*[BDFL]: Benevolent Dictator for Life
*[BJData]: Binary JData
*[BSON]: Binary JSON
*[CBOR]: Concise Binary Object Representation
*[CC0]: Creative Commons Zero
*[CI]: Continuous Integration
*[DOM]: Document Object Model
*[EOF]: End of File
*[FAQ]: Frequently Asked Questions
*[GCC]: GNU Compiler Collection
*[HTTP]: Hypertext Transfer Protocol
*[ICC]: Intel C++ Compiler
*[IEEE]: Institute of Electrical and Electronics Engineers
*[ISO]: International Organization for Standardization
*[JSON]: JavaScript Object Notation
*[MIT]: Massachusetts Institute of Technology
*[MSVC]: Microsoft Visual C++
*[MsgPack]: MessagePack
*[NASA]: National Aeronautics and Space Administration
*[NDK]: Native Development Kit
*[NaN]: Not a Number
*[RFC]: Request for Comments
*[RTTI]: Runtime Type Information
*[SAX]: Simple API for XML
*[SDK]: Software Development Kit
*[SFINAE]: Substitution failure is not an error
*[SHA]: Secure Hash Algorithm
*[SPDX]: Software Package Data Exchange
*[STL]: Standard Template Library
*[UBJSON]: Universal Binary JSON
*[UTF]: Unicode Transformation Format
